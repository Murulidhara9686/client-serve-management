/* ============================================================
   ClientServe — Global Professional UI JS
   ============================================================ */
(function () {
  'use strict';

  /* ── Page progress bar ──────────────────────────────────────── */
  function initProgress() {
    const bar = document.createElement('div');
    bar.id = 'pageProgress';
    document.body.appendChild(bar);
    let w = 0;
    const iv = setInterval(() => {
      w = w < 85 ? w + (85 - w) * 0.07 : w;
      bar.style.width = w + '%';
    }, 60);
    window.addEventListener('load', () => {
      clearInterval(iv);
      bar.style.width = '100%';
      setTimeout(() => { bar.style.opacity = '0'; }, 300);
    });
  }

  /* ── Scroll-to-top button ───────────────────────────────────── */
  function initScrollTop() {
    const btn = document.createElement('button');
    btn.id = 'scrollTopBtn';
    btn.title = 'Back to top';
    btn.setAttribute('data-tip', 'Back to top');
    btn.innerHTML = '↑';
    document.body.appendChild(btn);
    window.addEventListener('scroll', () => {
      btn.classList.toggle('visible', window.scrollY > 280);
    }, { passive: true });
    btn.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  /* ── Toast auto-dismiss ─────────────────────────────────────── */
  function initToasts() {
    document.querySelectorAll('.toast').forEach(t => {
      setTimeout(() => {
        t.style.transition = 'opacity .5s, transform .5s';
        t.style.opacity = '0';
        t.style.transform = 'translateY(-8px)';
        setTimeout(() => t.remove(), 500);
      }, 3500);
    });
  }

  /* ── Ripple effect on primary buttons ──────────────────────── */
  function initRipples() {
    document.querySelectorAll('.bsub, .abtn.ab-a, .btn-login, .btn-submit').forEach(btn => {
      btn.classList.add('ripple-host');
      btn.addEventListener('click', e => {
        const r = document.createElement('span');
        r.className = 'ripple';
        const rect = btn.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        r.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX-rect.left-size/2}px;top:${e.clientY-rect.top-size/2}px`;
        btn.appendChild(r);
        setTimeout(() => r.remove(), 600);
      });
    });
  }

  /* ── Notification bell shake ────────────────────────────────── */
  function initBellShake() {
    const bell = document.querySelector('.bell-btn');
    if (!bell) return;
    const dot = document.querySelector('.bell-dot');
    if (dot) {
      setTimeout(() => {
        bell.classList.add('shake');
        bell.addEventListener('animationend', () => bell.classList.remove('shake'), { once: true });
      }, 1200);
    }
  }

  /* ── Search input with clear button ────────────────────────── */
  function initSearchClear() {
    document.querySelectorAll('.srch').forEach(input => {
      const parent = input.parentElement;
      // Wrap if not already wrapped
      if (!parent.classList.contains('srch-wrap')) {
        const wrap = document.createElement('div');
        wrap.className = 'srch-wrap';
        input.parentNode.insertBefore(wrap, input);
        wrap.appendChild(input);

        const clearBtn = document.createElement('button');
        clearBtn.type = 'button';
        clearBtn.className = 'srch-clear';
        clearBtn.innerHTML = '✕';
        wrap.appendChild(clearBtn);

        input.addEventListener('input', () => {
          clearBtn.classList.toggle('show', input.value.length > 0);
        });
        clearBtn.addEventListener('click', () => {
          input.value = '';
          clearBtn.classList.remove('show');
          input.dispatchEvent(new Event('input'));
          input.focus();
        });
      }
    });
  }

  /* ── Enhanced char counters ─────────────────────────────────── */
  function initCharCounters() {
    document.querySelectorAll('.char-c').forEach(counter => {
      const textarea = counter.previousElementSibling;
      if (!textarea) return;
      const max = textarea.maxLength;
      if (max <= 0) return;
      textarea.addEventListener('input', () => {
        const rem = max - textarea.value.length;
        counter.textContent = `${rem} chars remaining`;
        counter.classList.toggle('warn', rem < max * 0.15);
        counter.classList.toggle('danger', rem < max * 0.05);
      });
    });
  }

  /* ── Command palette ────────────────────────────────────────── */
  function initCommandPalette() {
    // Build palette from nav links
    const links = [];
    document.querySelectorAll('.nav a, .nav button[type=submit]').forEach(el => {
      const text = el.textContent.trim().replace(/^[→←↑↓]/,'').trim();
      if (text && text.length > 1 && el.href && !el.href.includes('javascript')) {
        links.push({ label: text, href: el.href, icon: getIcon(text) });
      }
    });

    if (links.length === 0) return; // no nav links to show

    const overlay = document.createElement('div');
    overlay.id = 'cmdPalette';
    overlay.innerHTML = `
      <div class="cmd-box">
        <div class="cmd-input-wrap">
          <span class="cmd-icon">⌘</span>
          <input class="cmd-input" placeholder="Quick navigate…" autocomplete="off" spellcheck="false"/>
          <span class="cmd-esc" onclick="closePalette()">ESC</span>
        </div>
        <div class="cmd-list" id="cmdList"></div>
      </div>`;
    document.body.appendChild(overlay);

    const input = overlay.querySelector('.cmd-input');
    const list = overlay.querySelector('#cmdList');
    let selected = 0;

    function getIcon(label) {
      const l = label.toLowerCase();
      if (l.includes('stat') || l.includes('analytic')) return '📊';
      if (l.includes('team') || l.includes('user')) return '👥';
      if (l.includes('dashboard')) return '🏠';
      if (l.includes('sign out') || l.includes('logout')) return '🚪';
      if (l.includes('profile')) return '👤';
      if (l.includes('notif')) return '🔔';
      return '→';
    }

    function renderList(q) {
      const filtered = links.filter(l => l.label.toLowerCase().includes(q.toLowerCase()));
      if (filtered.length === 0) {
        list.innerHTML = '<div class="cmd-empty">No results found</div>';
        return;
      }
      list.innerHTML = filtered.map((l, i) => `
        <div class="cmd-item${i === selected ? ' selected' : ''}" onclick="window.location='${l.href}'">
          <div class="cmd-item-icon">${l.icon}</div>
          <span class="cmd-item-label">${l.label}</span>
          <span class="cmd-item-hint">↵ Go</span>
        </div>`).join('');
    }

    window.closePalette = () => {
      overlay.classList.remove('open');
      input.value = '';
      selected = 0;
    };

    input.addEventListener('input', () => { selected = 0; renderList(input.value); });
    input.addEventListener('keydown', e => {
      const items = list.querySelectorAll('.cmd-item');
      if (e.key === 'ArrowDown') { e.preventDefault(); selected = Math.min(selected+1, items.length-1); renderList(input.value); }
      if (e.key === 'ArrowUp')   { e.preventDefault(); selected = Math.max(selected-1, 0); renderList(input.value); }
      if (e.key === 'Enter') {
        const active = list.querySelector('.cmd-item.selected') || items[0];
        if (active) active.click();
      }
      if (e.key === 'Escape') closePalette();
    });

    overlay.addEventListener('click', e => { if (e.target === overlay) closePalette(); });

    // Keyboard shortcut: Ctrl+K or Cmd+K
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        overlay.classList.toggle('open');
        if (overlay.classList.contains('open')) {
          renderList('');
          setTimeout(() => input.focus(), 50);
        }
      }
      if (e.key === 'Escape' && overlay.classList.contains('open')) {
        closePalette();
      }
    });
  }

  /* ── Table row highlight on click ───────────────────────────── */
  function initRowHighlight() {
    document.querySelectorAll('tbody tr').forEach(row => {
      row.addEventListener('click', () => {
        document.querySelectorAll('tbody tr').forEach(r => r.classList.remove('highlight-row'));
        row.classList.add('highlight-row');
        setTimeout(() => row.classList.remove('highlight-row'), 1500);
      });
    });
  }

  /* ── Keyboard shortcut hints in nav ─────────────────────────── */
  function addKeyHint() {
    // Add ⌘K hint to first nav ghost button if present
    const ghostBtns = document.querySelectorAll('.nbtn-ghost');
    if (ghostBtns.length > 0 && !document.querySelector('.cmd-hint')) {
      const hint = document.createElement('span');
      hint.className = 'cmd-hint kbd';
      hint.style.cssText = 'margin-left:4px;opacity:.6;font-size:.62rem';
      hint.textContent = '⌘K';
      const nav = document.querySelector('.nav-r');
      if (nav) nav.insertBefore(hint, nav.firstChild);
    }
  }

  /* ── Form submit loading state ──────────────────────────────── */
  function initFormLoading() {
    document.querySelectorAll('form').forEach(form => {
      form.addEventListener('submit', () => {
        const btn = form.querySelector('button[type=submit], .bsub, .btn-login, .btn-submit');
        if (btn && !btn.dataset.loading) {
          btn.dataset.loading = '1';
          const orig = btn.innerHTML;
          btn.innerHTML = `<span class="spinner"></span>`;
          btn.disabled = true;
          // Restore after 8s as safety net
          setTimeout(() => { btn.innerHTML = orig; btn.disabled = false; delete btn.dataset.loading; }, 8000);
        }
      });
    });
  }

  /* ── Intersection observer for cards ────────────────────────── */
  function initScrollReveal() {
    if (!('IntersectionObserver' in window)) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.tc, .trow').forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(12px)';
      el.style.transition = 'opacity .4s ease, transform .4s ease';
      obs.observe(el);
    });
  }

  /* ── Run all on DOM ready ────────────────────────────────────── */
  function init() {
    initProgress();
    initScrollTop();
    initToasts();
    initRipples();
    initBellShake();
    initSearchClear();
    initCharCounters();
    initCommandPalette();
    initRowHighlight();
    addKeyHint();
    initFormLoading();
    initScrollReveal();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
