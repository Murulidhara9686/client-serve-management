package com.csm.controller;

import com.csm.model.*;
import com.csm.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.List;

@Controller
@RequestMapping("/manager")
@RequiredArgsConstructor
public class ManagerController {
    private final UserService userService;
    private final ServiceRequestService requestService;
    private final NotificationService notifService;
    private final CommentService commentService;

    private User getCurrentUser(UserDetails ud) {
        return userService.findByEmail(ud.getUsername()).orElseThrow();
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails ud, Model model,
                            @RequestParam(required = false) String success) {
        User user = getCurrentUser(ud);
        List<ServiceRequest> all = requestService.findAll();
        List<User> assistants = userService.findByRole(Role.ASSISTANT_MANAGER);
        long unread = notifService.countUnread(user);
        model.addAttribute("user",         user);
        model.addAttribute("requests",     all);
        model.addAttribute("assistants",   assistants);
        model.addAttribute("notifications",notifService.getAllForUser(user));
        model.addAttribute("unreadCount",  unread);
        model.addAttribute("total",        (long) all.size());
        model.addAttribute("pending",      all.stream().filter(r->r.getStatus()==TaskStatus.PENDING).count());
        model.addAttribute("inProgress",   all.stream().filter(r->r.getStatus()==TaskStatus.IN_PROGRESS).count());
        model.addAttribute("completed",    all.stream().filter(r->r.getStatus()==TaskStatus.COMPLETED).count());
        model.addAttribute("rejected",     all.stream().filter(r->r.getStatus()==TaskStatus.REJECTED).count());
        if (success != null) model.addAttribute("successMsg", success);
        return "manager/dashboard";
    }

    @PostMapping("/request/assign/{id}")
    public String assignToAssistant(@PathVariable Long id,
                                    @RequestParam Long assistantId,
                                    @RequestParam(required = false) String managerNote,
                                    @AuthenticationPrincipal UserDetails ud,
                                    RedirectAttributes ra) {
        User manager = getCurrentUser(ud);
        requestService.findById(id).ifPresent(req -> {
            userService.findById(assistantId).ifPresent(assistant -> {
                req.setAssignedAssistant(assistant);
                req.setAssignedManager(manager);
                req.setStatus(TaskStatus.IN_PROGRESS);
                req.setManagerNote(managerNote != null && !managerNote.isBlank()
                        ? managerNote.trim() : "Approved by Manager");
                requestService.save(req);
                // Notify assistant
                notifService.send(assistant,
                    "You have been assigned request: "" + req.getTitle() + """,
                    "SUCCESS", "/assistant/dashboard");
                // Notify customer
                notifService.send(req.getCustomer(),
                    "Your request "" + req.getTitle() + "" is now In Progress.",
                    "SUCCESS", "/customer/dashboard");
            });
        });
        ra.addAttribute("success", "Request assigned to assistant manager!");
        return "redirect:/manager/dashboard";
    }

    @PostMapping("/request/reject/{id}")
    public String rejectRequest(@PathVariable Long id,
                                @RequestParam(required = false) String managerNote,
                                RedirectAttributes ra) {
        requestService.findById(id).ifPresent(req -> {
            if (req.getStatus()==TaskStatus.PENDING) {
                req.setStatus(TaskStatus.REJECTED);
                req.setManagerNote(managerNote != null && !managerNote.isBlank()
                        ? managerNote.trim() : "Request rejected by Manager.");
                requestService.save(req);
                notifService.send(req.getCustomer(),
                    "Your request "" + req.getTitle() + "" was rejected. Reason: " + req.getManagerNote(),
                    "ALERT", "/customer/dashboard");
            }
        });
        ra.addAttribute("success", "Request rejected.");
        return "redirect:/manager/dashboard";
    }

    @PostMapping("/request/comment/{id}")
    public String addComment(@PathVariable Long id,
                             @RequestParam String content,
                             @AuthenticationPrincipal UserDetails ud,
                             RedirectAttributes ra) {
        User user = getCurrentUser(ud);
        requestService.findById(id).ifPresent(r -> {
            if (!content.isBlank()) {
                commentService.add(r, user, content);
                notifService.send(r.getCustomer(),
                    "Manager commented on your request "" + r.getTitle() + """,
                    "INFO", "/customer/dashboard");
            }
        });
        ra.addAttribute("success", "Comment added.");
        return "redirect:/manager/dashboard";
    }

    @PostMapping("/notifications/mark-read")
    public String markRead(@AuthenticationPrincipal UserDetails ud) {
        notifService.markAllRead(getCurrentUser(ud));
        return "redirect:/manager/dashboard";
    }

    /* ── User Management ── */
    @GetMapping("/users")
    public String users(@AuthenticationPrincipal UserDetails ud, Model model) {
        model.addAttribute("user",      getCurrentUser(ud));
        model.addAttribute("employees", userService.findByRole(Role.EMPLOYEE));
        model.addAttribute("assistants",userService.findByRole(Role.ASSISTANT_MANAGER));
        model.addAttribute("customers", userService.findByRole(Role.CUSTOMER));
        return "manager/users";
    }
}
