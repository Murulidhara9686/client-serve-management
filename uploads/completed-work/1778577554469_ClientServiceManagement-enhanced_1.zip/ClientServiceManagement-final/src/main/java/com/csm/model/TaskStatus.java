package com.csm.model;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    REJECTED
}
