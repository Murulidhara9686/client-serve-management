package com.csm.controller;

import com.csm.model.*;
import com.csm.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/customer")
@RequiredArgsConstructor
public class CustomerController {

    private final UserService userService;
    private final ServiceRequestService requestService;
    private final NotificationService notifService;
    private final CommentService commentService;

    private User getCurrentUser(UserDetails ud) {
        return userService.findByEmail(ud.getUsername()).orElseThrow();
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails ud, Model model,
                            @RequestParam(required = false) String success,
                            @RequestParam(required = false) String error) {
        User user = getCurrentUser(ud);
        List<ServiceRequest> requests = requestService.findByCustomer(user);
        long unread = notifService.countUnread(user);
        model.addAttribute("user",         user);
        model.addAttribute("requests",     requests);
        model.addAttribute("notifications",notifService.getAllForUser(user));
        model.addAttribute("unreadCount",  unread);
        model.addAttribute("categories",   List.of(
            "Web Development","Mobile App","Database","API Integration",
            "Cloud Services","UI/UX Design","Data Analytics","DevOps","Other"));
        model.addAttribute("priorities",   Priority.values());
        model.addAttribute("total",        (long) requests.size());
        model.addAttribute("pending",      requests.stream().filter(r -> r.getStatus()==TaskStatus.PENDING).count());
        model.addAttribute("inProgress",   requests.stream().filter(r -> r.getStatus()==TaskStatus.IN_PROGRESS).count());
        model.addAttribute("completed",    requests.stream().filter(r -> r.getStatus()==TaskStatus.COMPLETED).count());
        if (success != null) model.addAttribute("successMsg", success);
        if (error   != null) model.addAttribute("errorMsg",   error);
        return "customer/dashboard";
    }

    @PostMapping("/request/submit")
    public String submitRequest(
            @RequestParam String title,
            @RequestParam String description,
            @RequestParam String category,
            @RequestParam(defaultValue = "MEDIUM") String priority,
            @RequestParam(required = false) String budgetRange,
            @RequestParam(required = false) String expectedDeadline,
            @AuthenticationPrincipal UserDetails ud,
            RedirectAttributes ra) {
        User user = getCurrentUser(ud);
        ServiceRequest req = new ServiceRequest();
        req.setTitle(title.trim());
        req.setDescription(description.trim());
        req.setCategory(category.isEmpty() ? "Other" : category);
        req.setBudgetRange(budgetRange);
        if (expectedDeadline != null && !expectedDeadline.isEmpty()) {
            try { req.setExpectedDeadline(LocalDate.parse(expectedDeadline)); } catch (Exception ignored) {}
        }
        try { req.setPriority(Priority.valueOf(priority)); } catch (Exception e) { req.setPriority(Priority.MEDIUM); }
        req.setCustomer(user);
        requestService.save(req);
        // Notify all managers
        userService.findByRole(Role.MANAGER).forEach(mgr ->
            notifService.send(mgr, "New request from " + user.getName() + ": "" + req.getTitle() + """,
                "INFO", "/manager/dashboard"));
        ra.addAttribute("success", "Request submitted! We'll get back to you shortly.");
        return "redirect:/customer/dashboard";
    }

    @PostMapping("/request/edit/{id}")
    public String editRequest(@PathVariable Long id,
                              @RequestParam String title,
                              @RequestParam String description,
                              @RequestParam String category,
                              @RequestParam(defaultValue = "MEDIUM") String priority,
                              @RequestParam(required = false) String budgetRange,
                              @RequestParam(required = false) String expectedDeadline,
                              @AuthenticationPrincipal UserDetails ud,
                              RedirectAttributes ra) {
        User user = getCurrentUser(ud);
        requestService.findById(id).ifPresent(r -> {
            if (r.getCustomer().getId().equals(user.getId()) && r.getStatus()==TaskStatus.PENDING) {
                r.setTitle(title.trim());
                r.setDescription(description.trim());
                r.setCategory(category.isEmpty() ? "Other" : category);
                r.setBudgetRange(budgetRange);
                if (expectedDeadline != null && !expectedDeadline.isEmpty()) {
                    try { r.setExpectedDeadline(LocalDate.parse(expectedDeadline)); } catch (Exception ignored) {}
                } else { r.setExpectedDeadline(null); }
                try { r.setPriority(Priority.valueOf(priority)); } catch (Exception e) { r.setPriority(Priority.MEDIUM); }
                requestService.save(r);
            }
        });
        ra.addAttribute("success", "Request updated.");
        return "redirect:/customer/dashboard";
    }

    @PostMapping("/request/cancel/{id}")
    public String cancelRequest(@PathVariable Long id,
                                @AuthenticationPrincipal UserDetails ud,
                                RedirectAttributes ra) {
        User user = getCurrentUser(ud);
        requestService.findById(id).ifPresent(r -> {
            if (r.getCustomer().getId().equals(user.getId()) && r.getStatus()==TaskStatus.PENDING) {
                requestService.deleteById(id);
            }
        });
        ra.addAttribute("success", "Request cancelled.");
        return "redirect:/customer/dashboard";
    }

    @PostMapping("/request/rate/{id}")
    public String rateRequest(@PathVariable Long id,
                              @RequestParam(defaultValue = "0") int rating,
                              @RequestParam(required = false) String feedback,
                              @AuthenticationPrincipal UserDetails ud,
                              RedirectAttributes ra) {
        User user = getCurrentUser(ud);
        requestService.findById(id).ifPresent(r -> {
            if (r.getCustomer().getId().equals(user.getId()) && r.getStatus()==TaskStatus.COMPLETED) {
                if (rating >= 1 && rating <= 5) r.setCustomerRating(rating);
                if (feedback != null && !feedback.isBlank()) r.setCustomerFeedback(feedback.trim());
                requestService.save(r);
            }
        });
        ra.addAttribute("success", "Thank you for your feedback!");
        return "redirect:/customer/dashboard";
    }

    @PostMapping("/request/comment/{id}")
    public String addComment(@PathVariable Long id,
                             @RequestParam String content,
                             @AuthenticationPrincipal UserDetails ud,
                             RedirectAttributes ra) {
        User user = getCurrentUser(ud);
        requestService.findById(id).ifPresent(r -> {
            if (r.getCustomer().getId().equals(user.getId()) && !content.isBlank()) {
                commentService.add(r, user, content);
                // notify assigned employee/assistant
                if (r.getAssignedEmployee() != null)
                    notifService.send(r.getAssignedEmployee(),
                        "New comment from " + user.getName() + " on "" + r.getTitle() + """,
                        "INFO", "/employee/dashboard");
                if (r.getAssignedAssistant() != null)
                    notifService.send(r.getAssignedAssistant(),
                        "New comment from " + user.getName() + " on "" + r.getTitle() + """,
                        "INFO", "/assistant/dashboard");
            }
        });
        ra.addAttribute("success", "Comment added.");
        return "redirect:/customer/dashboard";
    }

    @PostMapping("/notifications/mark-read")
    public String markNotificationsRead(@AuthenticationPrincipal UserDetails ud) {
        notifService.markAllRead(getCurrentUser(ud));
        return "redirect:/customer/dashboard";
    }

    @GetMapping("/profile")
    public String profilePage(@AuthenticationPrincipal UserDetails ud, Model model) {
        model.addAttribute("user", getCurrentUser(ud));
        return "customer/profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@RequestParam String name,
                                @RequestParam(required = false) String phone,
                                @AuthenticationPrincipal UserDetails ud,
                                RedirectAttributes ra) {
        User user = getCurrentUser(ud);
        user.setName(name.trim());
        user.setPhone(phone != null ? phone.trim() : null);
        userService.save(user);
        ra.addAttribute("success", "Profile updated successfully.");
        return "redirect:/customer/dashboard";
    }
}
