package com.csm.repository;

import com.csm.model.ServiceRequest;
import com.csm.model.TaskStatus;
import com.csm.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ServiceRequestRepository extends JpaRepository<ServiceRequest, Long> {
    List<ServiceRequest> findByCustomer(User customer);
    List<ServiceRequest> findByAssignedAssistant(User assistant);
    List<ServiceRequest> findByAssignedEmployee(User employee);
    List<ServiceRequest> findByStatus(TaskStatus status);
    long countByStatus(TaskStatus status);
    List<ServiceRequest> findByOrderByCreatedAtDesc();
}
