package com.csm.service;

import com.csm.model.ServiceRequest;
import com.csm.model.TaskStatus;
import com.csm.model.User;
import com.csm.repository.ServiceRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ServiceRequestService {
    private final ServiceRequestRepository repo;

    @Transactional
    public ServiceRequest save(ServiceRequest req) { return repo.save(req); }

    @Transactional(readOnly = true)
    public Optional<ServiceRequest> findById(Long id) { return repo.findById(id); }

    @Transactional(readOnly = true)
    public List<ServiceRequest> findAll() { return repo.findByOrderByCreatedAtDesc(); }

    @Transactional(readOnly = true)
    public List<ServiceRequest> findByCustomer(User c) { return repo.findByCustomer(c); }

    @Transactional(readOnly = true)
    public List<ServiceRequest> findByAssistant(User a) { return repo.findByAssignedAssistant(a); }

    @Transactional(readOnly = true)
    public List<ServiceRequest> findByEmployee(User e) { return repo.findByAssignedEmployee(e); }

    @Transactional(readOnly = true)
    public long countByStatus(TaskStatus s) { return repo.countByStatus(s); }

    @Transactional
    public void deleteById(Long id) { repo.deleteById(id); }
}
